package com.example.monitoring;

public class Image {
}
